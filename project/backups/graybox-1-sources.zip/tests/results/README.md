# Verified graybox results

Final multiplayer regression: **55/55 checks passed** using two real Studio clients, followed by a real disconnect and replacement join. `multiplayer.json` contains the final structured report.

Direct client smoke test: **passed**. E-key theft and ordinary-speed navigation earned $50; E-key Speed upgrade spent $50 and changed actual WalkSpeed from 16 to 18. Real death/respawn retained progress and exactly one HUD. A subsequent repeat earned $50; stopping and starting Play reloaded $50, Speed level 1 and WalkSpeed 18, with 15 available packages and zero leftover chasers/carried visuals. `client-smoke.json` records the observed states.

Roblox persistence: the multiplayer runner saved/reopened an isolated disposable QA key and removed it. Actual positive-UserId Studio profile progress was also verified across fresh Play sessions. Studio test keys are separate from live player keys.

`initial-multiplayer.json` preserves the first run's invalid server-side HUD assertion for audit. Client-created GUI objects do not replicate to the server; this test assertion was corrected and the HUD verified directly in the Client DataModel. It was not a game-system failure.

The game uses primitive geometry, a temporary HUD, one package per player and only Speed upgrades. No Rojo or final art/UI/monetization was introduced.
