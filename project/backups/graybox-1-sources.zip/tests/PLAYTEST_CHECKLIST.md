# Graybox verification

Automated: run the opt-in Graybox suite with two real Studio clients. Inspect `tests/results/` for actual run results.

- Separate plots and concurrent chases in the same area.
- Atomic package claim, one-package limit, distance checks.
- Own-plot deposits once; other plots cannot deposit or upgrade for another player.
- Catch removes carried package/chaser without reward.
- All five areas open; chaser speeds increase with depth; correct rewards.
- Starter Street is escapable at base speed; Facility catches a base-speed runner.
- Speed spends cash and changes Humanoid.WalkSpeed; insufficient funds rejected.
- Death/reset retain cash/Speed and clear carried state; respawn at own plot.
- Repeated thefts leave bounded package, chaser and carried-visual populations.
- Player disconnect releases plot, prompt connection, mirror/profile, chase and visual.
- Replacement client reuses released plot.
- Session leases, serialization, stale-server rejection, expired-lease recovery and malformed profile handling.
- Real Roblox DataStore roundtrip in a disposable QA store/key.

Direct client smoke checks:

1. Use real E-key pickup prompt and walk back at ordinary speed to earn cash.
2. Use real E-key Speed station prompt and confirm the temporary HUD and actual WalkSpeed.
3. Reset/die, confirm HUD survives and spawn/Speed remain correct.
4. Stop and start Play; confirm cash/Speed reload from actual Roblox storage.

No gameplay success is inferred merely from source inspection. The automated movement cases control server character positions to test the authoritative chase/transaction loop; the direct client smoke test also exercises Roblox prompt input and character navigation.
