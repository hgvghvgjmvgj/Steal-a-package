# Studio hierarchy

```
Workspace
  StealAPackage
    Map
      Areas / StarterStreet, Neighborhood, RichStreet, Mansion, Facility
      Plots / Plot01… (runtime owner attributes)
    Packages / runtime packages
    Chasers / runtime chasers
    CarriedPackages / welded package visuals
ReplicatedStorage
  StealAPackage
    Shared
      Configs / GameConfig, AreaConfig, UpgradeConfig
      Modules / ProfileSchema
    Remotes / Notice (server → client)
    Assets / UI, Models
ServerStorage
  StealAPackage
    Templates / Package, Chaser
    PlayerData / runtime server-only profile mirrors
ServerScriptService
  StealAPackage
    Bootstrap
    Systems / WorldBuilder, PlotService, PackageService, ChaserService, UpgradeService
    Data / ProfileStore, DataService
    Tests / GrayboxTests (Studio-only, opt-in)
StarterPlayer
  StarterPlayerScripts
    StealAPackageClient / PlaytestHUD
```

Shared configs are the sole graybox balance defaults. Saving stores only player cash and Speed level, never tunables. WorldBuilder builds primitive geometry in Edit mode through MCP. Bootstrap initializes runtime systems in dependency order. Server proximity and state checks protect all prompts; clients only render feedback.

Local source → Studio mapping lives in `tools/studio/manifest.json`. Direct MCP writes install sources; there is no live sync or Rojo project.
