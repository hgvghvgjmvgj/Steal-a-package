# Basic saving

Only Cash, SpeedLevel and schema Version are persistent. Carried packages, chasers, plot assignments and spawn cooldowns are session state and clear on respawn/leave/server stop.

ProfileStore uses UpdateAsync for acquisition and writes. A renewable 180-second session lease prevents concurrent servers from overwriting the same profile. Autosaves run every 45 seconds; Speed purchases also request a save; player leave and BindToClose save and release the lease. Failed loads never overwrite existing data with defaults in a live server. Numeric profile fields are normalized.

Store: `StealAPackage_Graybox_v1`. Live keys use `player:<UserId>`. Studio uses `studio:<UserId>` to keep test progress separate. The opt-in persistence regression uses `StealAPackage_Graybox_v1_QA` with a disposable key.

If API access is disabled, Studio alone falls back to session-only data and the HUD says `SessionOnly`; this mode is not persistent. Live load failures kick with a rejoin message. Failed writes keep in-memory values for later retries and show `SaveFailed`.

Enable File → Experience Settings → Security → Enable Studio Access to API Services for a real write/reload test. This place is a new test project. Do not reuse Studio test keys for live players.

This is a graybox persistence layer. Before a public content release, add migrations and operational recovery tools appropriate to the final data model.
